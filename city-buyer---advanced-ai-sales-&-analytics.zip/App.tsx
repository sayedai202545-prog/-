
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Search, Plus, LogOut, LayoutGrid, List, Filter, 
  TrendingUp, Home, UserCircle, PieChart, Upload, 
  Trash2, Edit3, Image as ImageIcon, Save, X,
  Users, LayoutDashboard, Tag, Settings, Briefcase, Info,
  Clock, XCircle, Calculator as CalcIcon, Percent, Calendar, DollarSign,
  User as UserIcon, Share2, MessageSquare, Send, Sparkles, ExternalLink,
  BarChart3, LineChart, Target, ShieldCheck, Zap, ChevronLeft, ChevronRight,
  FileText, Download, Wallet, CreditCard, Mic, Volume2, BrainCircuit, 
  Maximize, Camera, MapPin, Loader2, Map as MapIcon, Layers, FileSpreadsheet,
  Building2, Activity, PieChart as PieChartIcon, CheckSquare, Square, Lock, Key, ZoomIn
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Unit, UnitStatus, User } from './types';
import { STATUS_LABELS, INITIAL_UNITS } from './constants';
import * as XLSX from 'xlsx';
import { 
  PieChart as RePieChart, Pie, Cell, ResponsiveContainer, 
  Tooltip as ReTooltip, BarChart, Bar, XAxis, YAxis, 
  CartesianGrid, AreaChart, Area, Legend 
} from 'recharts';
import { GoogleGenAI, Type, Modality } from "@google/genai";

// --- Types Expansion ---
type ViewType = 'DASHBOARD' | 'INVENTORY' | 'FLOOR_PLAN' | 'ANALYTICS' | 'MARKETING' | 'REPORTS';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  image?: string;
  audio?: string;
  isThinking?: boolean;
}

// Helper for Base64 image processing
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

// --- Status Component ---
const StatusBadge: React.FC<{ status: UnitStatus }> = ({ status }) => {
  const config = STATUS_LABELS[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black border ${config.color} uppercase tracking-tighter`}>
      {config.icon}
      {config.label}
    </span>
  );
};

export default function App() {
  // State Management
  const [units, setUnits] = useState<Unit[]>(() => {
    const saved = localStorage.getItem('citybuyer_units');
    return saved ? JSON.parse(saved) : INITIAL_UNITS;
  });
  
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('citybuyer_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [currentView, setCurrentView] = useState<ViewType>('DASHBOARD');
  const [filter, setFilter] = useState<string>('ALL');
  const [search, setSearch] = useState('');
  const [selectedFloor, setSelectedFloor] = useState<'الأرضي' | 'الأول' | 'الثاني'>('الأرضي');
  const [floorPlanTypeFilter, setFloorPlanTypeFilter] = useState<string>('ALL');
  const [floorPlanSearch, setFloorPlanSearch] = useState('');
  
  // Floor Plan Image Map
  const [floorPlanImages, setFloorPlanImages] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem('citybuyer_floorplans');
    return saved ? JSON.parse(saved) : {};
  });

  // Admin Login State
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');

  // Selection State
  const [selectedUnitIds, setSelectedUnitIds] = useState<string[]>([]);
  
  // Modals
  const [isAddingUnit, setIsAddingUnit] = useState(false);
  const [editingUnit, setEditingUnit] = useState<Unit | null>(null);
  const [calculatingUnit, setCalculatingUnit] = useState<Unit | null>(null);
  const [unitImagePreview, setUnitImagePreview] = useState<string | null>(null);
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null);

  // Calculator State
  const [calcPricePerMeter, setCalcPricePerMeter] = useState<number>(0);
  const [calcArea, setCalcArea] = useState<number>(0);
  const [calcDownPaymentPercent, setCalcDownPaymentPercent] = useState<number>(10);
  const [calcYears, setCalcYears] = useState<number>(5);

  const calculatedTotal = useMemo(() => calcPricePerMeter * calcArea, [calcPricePerMeter, calcArea]);
  const calculatedDownPayment = useMemo(() => calculatedTotal * (calcDownPaymentPercent / 100), [calculatedTotal, calcDownPaymentPercent]);
  const calculatedRemaining = useMemo(() => calculatedTotal - calculatedDownPayment, [calculatedTotal, calcDownPaymentPercent]);
  const calculatedMonthly = useMemo(() => calcYears > 0 ? calculatedRemaining / (calcYears * 12) : 0, [calculatedRemaining, calcYears]);

  useEffect(() => {
    if (calculatingUnit) {
      setCalcArea(calculatingUnit.area);
      const ppm = calculatingUnit.area > 0 ? Math.round(calculatingUnit.price / calculatingUnit.area) : 0;
      setCalcPricePerMeter(ppm);
    }
  }, [calculatingUnit]);

  useEffect(() => {
    if (editingUnit) {
      setUnitImagePreview(editingUnit.imageUrl || null);
    } else {
      setUnitImagePreview(null);
    }
  }, [editingUnit]);

  useEffect(() => {
    localStorage.setItem('citybuyer_floorplans', JSON.stringify(floorPlanImages));
  }, [floorPlanImages]);

  // AI Assistant State
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'مرحباً بك في City Buyer AI المتطور. كيف يمكنني مساعدتك اليوم بخصوص المشروع والوحدات المتاحة؟' }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem('citybuyer_units', JSON.stringify(units));
  }, [units]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Auth Logic
  const handleAdminLogin = () => {
    if (adminPasswordInput === 'admin123') {
      const user: User = { id: 'admin', name: 'سيد إبراهيم', role: 'ADMIN' };
      setCurrentUser(user);
      localStorage.setItem('citybuyer_user', JSON.stringify(user));
      setShowAdminLogin(false);
      setAdminPasswordInput('');
      setLoginError('');
    } else {
      setLoginError('كلمة المرور غير صحيحة');
    }
  };

  const loginSales = () => {
    const user: User = { id: Math.random().toString(36).substr(2, 9), name: 'عضوة مبيعات', role: 'SALES' };
    setCurrentUser(user);
    localStorage.setItem('citybuyer_user', JSON.stringify(user));
  };

  const logout = () => { 
    setCurrentUser(null); 
    localStorage.removeItem('citybuyer_user'); 
    setShowAdminLogin(false);
  };

  const analyticsData = useMemo(() => {
    const soldCount = units.filter(u => u.status === UnitStatus.SOLD).length;
    const reservedCount = units.filter(u => u.status === UnitStatus.RESERVED).length;
    const availableCount = units.filter(u => u.status === UnitStatus.AVAILABLE).length;
    const soldValue = units.filter(u => u.status === UnitStatus.SOLD).reduce((acc, curr) => acc + curr.price, 0);
    const floorStats = units.reduce((acc: any, u) => {
      acc[u.floor] = acc[u.floor] || { name: u.floor, sold: 0, total: 0 };
      acc[u.floor].total++;
      if (u.status === UnitStatus.SOLD) acc[u.floor].sold++;
      return acc;
    }, {});
    return { soldCount, reservedCount, availableCount, totalCount: units.length, soldValue, floorChart: Object.values(floorStats), pieData: [{ name: 'مباع', value: soldCount, color: '#ef4444' }, { name: 'محجوز', value: reservedCount, color: '#f59e0b' }, { name: 'متاح', value: availableCount, color: '#22c55e' }] };
  }, [units]);

  // Filtered units for inventory view
  const filteredInventoryUnits = useMemo(() => {
    return units.filter(u => (filter === 'ALL' || u.status === filter) && (u.code.toLowerCase().includes(search.toLowerCase()) || u.soldTo?.toLowerCase().includes(search.toLowerCase())));
  }, [units, filter, search]);

  const toggleSelectAll = () => {
    if (selectedUnitIds.length === filteredInventoryUnits.length) {
      setSelectedUnitIds([]);
    } else {
      setSelectedUnitIds(filteredInventoryUnits.map(u => u.id));
    }
  };

  const toggleSelectUnit = (id: string) => {
    setSelectedUnitIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const deleteSelectedUnits = () => {
    if (confirm(`هل أنت متأكد من حذف ${selectedUnitIds.length} وحدة؟`)) {
      setUnits(prev => prev.filter(u => !selectedUnitIds.includes(u.id)));
      setSelectedUnitIds([]);
    }
  };

  const deleteUnit = (id: string) => {
    if (confirm(`هل أنت متأكد من حذف هذه الوحدة؟`)) {
      setUnits(prev => prev.filter(u => u.id !== id));
      setSelectedUnitIds(prev => prev.filter(x => x !== id));
    }
  };

  const handleShareUnit = async (unit: Unit) => {
    const shareText = `وحدة عقارية مميزة في سيتي باير:\nالكود: ${unit.code}\nالنوع: ${unit.type}\nالمساحة: ${unit.area} م²\nالسعر: ${unit.price.toLocaleString()} ج.م`;
    const shareUrl = window.location.origin;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `City Buyer - ${unit.code}`,
          text: shareText,
          url: shareUrl,
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      try {
        await navigator.clipboard.writeText(`${shareText}\nالرابط: ${shareUrl}`);
        alert('تم نسخ تفاصيل الوحدة والرابط للحافظة بنجاح!');
      } catch (err) {
        console.error('Could not copy text: ', err);
      }
    }
  };

  const handleFloorPlanUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await fileToBase64(file);
      setFloorPlanImages(prev => ({ ...prev, [selectedFloor]: base64 }));
    }
  };

  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);
        
        const newUnits: Unit[] = data.map((item: any) => ({
          id: Math.random().toString(36).substr(2, 9),
          code: String(item.Code || item['الكود'] || 'Unknown'),
          type: String(item.Type || item['النوع'] || 'تجاري'),
          floor: String(item.Floor || item['الدور'] || 'الأرضي'),
          area: Number(item.Area || item['المساحة'] || 0),
          price: Number(item.Price || item['السعر'] || 0),
          status: (item.Status || item['الحالة']) === 'مباع' ? UnitStatus.SOLD : 
                  (item.Status || item['الحالة']) === 'محجوز' ? UnitStatus.RESERVED : 
                  UnitStatus.AVAILABLE,
          lastUpdate: Date.now(),
          x: Math.random() * 80 + 10,
          y: Math.random() * 80 + 10
        }));
        
        setUnits(prev => [...prev, ...newUnits]);
      } catch (err) {
        console.error("Excel import error:", err);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleSendMessage = async (textOverride?: string) => {
    const userMsg = textOverride || chatInput.trim();
    if (!userMsg) return;
    const newMsg: Message = { role: 'user', content: userMsg };
    setMessages(prev => [...prev, newMsg]);
    setChatInput('');
    setIsTyping(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const modelName = isThinkingMode ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
      
      const unitContext = units.slice(0, 15).map(u => ({
        code: u.code,
        price: u.price,
        status: u.status,
        area: u.area,
        type: u.type,
        floor: u.floor
      }));

      const response = await ai.models.generateContent({
        model: modelName,
        contents: [{ role: 'user', parts: [{ text: `معلومات المشروع الحالية: ${JSON.stringify(unitContext)}. استفسار المستخدم: ${userMsg}` }] }],
        config: {
          systemInstruction: `أنت مساعد مبيعات ذكي لنظام City Buyer. قدم إجابات محترفة ودقيقة حول الوحدات المتاحة والأسعار. المطور: سيد إبراهيم.`,
          tools: [{ googleSearch: {} }],
          thinkingConfig: isThinkingMode ? { thinkingBudget: 24576 } : undefined
        }
      });
      setMessages(prev => [...prev, { role: 'assistant', content: response.text || "عذراً، لم أستطع معالجة طلبك.", isThinking: isThinkingMode }]);
    } catch (error) { 
      setMessages(prev => [...prev, { role: 'assistant', content: "عذراً، حدث خطأ أثناء التواصل مع الذكاء الاصطناعي." }]); 
    } finally { 
      setIsTyping(false); 
    }
  };

  const handleUnitImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await fileToBase64(file);
      setUnitImagePreview(base64);
    }
  };

  const saveUnit = (unitData: Partial<Unit>) => {
    const dataWithImage = { ...unitData, imageUrl: unitImagePreview || undefined };
    if (editingUnit) { 
      setUnits(prev => prev.map(u => u.id === editingUnit.id ? { ...u, ...dataWithImage } as Unit : u)); 
    } else { 
      const newUnit: Unit = { 
        id: Math.random().toString(36).substr(2, 9), 
        code: unitData.code || '', 
        type: unitData.type || 'تجاري', 
        floor: unitData.floor || 'الأرضي', 
        area: unitData.area || 0, 
        price: unitData.price || 0, 
        status: unitData.status || UnitStatus.AVAILABLE, 
        lastUpdate: Date.now(),
        imageUrl: unitImagePreview || undefined,
        x: Math.random() * 80 + 10,
        y: Math.random() * 80 + 10
      }; 
      setUnits(prev => [...prev, newUnit]); 
    }
    setIsAddingUnit(false); 
    setEditingUnit(null);
    setUnitImagePreview(null);
  };

  const generateAIPost = async (unit: Unit) => {
    setIsTyping(true);
    setIsChatOpen(true);
    const prompt = `اكتب بوست تسويقي جذاب ومحترف لفيسبوك باللغة العربية عن هذه الوحدة العقارية:
    الكود: ${unit.code}, النوع: ${unit.type}, المساحة: ${unit.area} متر مربع, السعر: ${unit.price.toLocaleString()} جنيه مصري.
    اجعل الكلام مشوقاً ويركز على الموقع والفرصة الاستثمارية.`;
    handleSendMessage(prompt);
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-6 relative overflow-hidden text-right" dir="rtl">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_#4f46e522_0%,_transparent_50%)]"></div>
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-slate-900/50 backdrop-blur-3xl p-12 rounded-[3.5rem] shadow-2xl w-full max-w-lg text-center border border-white/5 z-10">
          <div className="mb-10 inline-flex p-6 bg-indigo-600 rounded-[2rem] shadow-2xl shadow-indigo-500/30"><Zap className="w-14 h-14 text-white" /></div>
          <h1 className="text-5xl font-black mb-3 text-white tracking-tighter">CITY BUYER</h1>
          <p className="text-slate-400 mb-12 font-bold text-lg">نظام المبيعات الذكي • تطوير سيد إبراهيم</p>
          
          <AnimatePresence mode="wait">
            {!showAdminLogin ? (
              <motion.div key="roles" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-4">
                <button onClick={() => setShowAdminLogin(true)} className="flex items-center justify-center gap-4 w-full py-6 bg-white text-slate-900 rounded-3xl hover:bg-slate-100 transition-all font-black text-xl shadow-xl active:scale-95"><ShieldCheck className="w-7 h-7 text-indigo-600" /> دخول الإدارة</button>
                <button onClick={loginSales} className="flex items-center justify-center gap-4 w-full py-6 bg-slate-800 text-white rounded-3xl hover:bg-slate-700 transition-all font-black text-xl border border-white/5 active:scale-95"><Briefcase className="w-7 h-7 text-indigo-400" /> دخول المبيعات</button>
              </motion.div>
            ) : (
              <motion.div key="admin-pass" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
                <div className="relative">
                   <Lock className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-500 w-6 h-6" />
                   <input 
                    type="password" 
                    autoFocus
                    placeholder="أدخل كلمة مرور المسؤول..." 
                    value={adminPasswordInput}
                    onChange={(e) => setAdminPasswordInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
                    className="w-full pr-16 pl-6 py-6 bg-slate-800 rounded-3xl font-black text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-center"
                   />
                </div>
                {loginError && <p className="text-red-400 font-bold text-sm">{loginError}</p>}
                <div className="flex gap-4">
                   <button onClick={handleAdminLogin} className="flex-1 py-5 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 shadow-xl transition-all">دخول</button>
                   <button onClick={() => { setShowAdminLogin(false); setLoginError(''); }} className="px-8 py-5 border border-white/5 text-slate-400 rounded-2xl font-black hover:bg-white/5 transition-all">إلغاء</button>
                </div>
                <p className="text-[10px] text-slate-600 font-bold">كلمة المرور الافتراضية: admin123</p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 flex flex-col md:flex-row font-cairo h-screen overflow-hidden text-right" dir="rtl">
      {/* Sidebar */}
      <aside className="w-full md:w-80 bg-[#0a0f1d] border-l border-white/5 p-8 flex flex-col shrink-0 z-40 h-full overflow-y-auto">
        <div className="flex items-center gap-4 mb-16 px-2">
          <div className="bg-indigo-600 p-3 rounded-2xl shadow-lg shadow-indigo-600/30"><Zap className="text-white w-7 h-7" /></div>
          <span className="text-2xl font-black text-white tracking-tighter">CITY BUYER</span>
        </div>
        <nav className="flex-1 space-y-2">
          <SidebarItem icon={<LayoutDashboard />} label="لوحة التحكم" active={currentView === 'DASHBOARD'} onClick={() => setCurrentView('DASHBOARD')} />
          <SidebarItem icon={<MapIcon />} label="المخطط التفاعلي" active={currentView === 'FLOOR_PLAN'} onClick={() => setCurrentView('FLOOR_PLAN')} />
          <SidebarItem icon={<Tag />} label="مستودع الوحدات" active={currentView === 'INVENTORY'} onClick={() => setCurrentView('INVENTORY')} />
          <SidebarItem icon={<BarChart3 />} label="تحليل البيانات" active={currentView === 'ANALYTICS'} onClick={() => setCurrentView('ANALYTICS')} />
          <SidebarItem icon={<Target />} label="التسويق الذكي" active={currentView === 'MARKETING'} onClick={() => setCurrentView('MARKETING')} />
          <SidebarItem icon={<FileText />} label="التقارير" active={currentView === 'REPORTS'} onClick={() => setCurrentView('REPORTS')} />
        </nav>
        <div className="mt-auto pt-8 border-t border-white/5 space-y-4">
          <button onClick={() => setIsChatOpen(true)} className="flex items-center justify-center gap-3 w-full py-4 bg-indigo-600/10 text-indigo-400 rounded-2xl font-black border border-indigo-500/20 hover:bg-indigo-600/20 transition-all"><Sparkles className="w-5 h-5" /> تحدث مع المساعد</button>
          <div className="bg-slate-800/40 rounded-3xl p-5 border border-white/5">
            <div className="flex items-center gap-4 mb-4">
              <img src={userAvatar} className="w-12 h-12 rounded-2xl border-2 border-indigo-500/30 shadow-lg" alt="User" />
              <div className="flex-1 overflow-hidden">
                <p className="font-black text-white truncate text-sm">{currentUser.name}</p>
                <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">{currentUser.role === 'ADMIN' ? 'مدير النظام' : 'فريق المبيعات'}</p>
              </div>
            </div>
            <button onClick={logout} className="text-red-400 hover:text-white font-bold py-2 w-full transition-all text-xs rounded-xl flex items-center justify-center gap-2"><LogOut className="w-4 h-4" /> خروج آمن</button>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto h-full p-6 md:p-10 bg-slate-900/20 relative">
        <AnimatePresence mode="wait">
          {/* FLOOR PLAN VIEW */}
          {currentView === 'FLOOR_PLAN' && (
            <motion.div key="floorplan" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="space-y-8 h-full flex flex-col">
               <header className="flex flex-col xl:flex-row xl:items-center justify-between gap-6">
                  <div><h2 className="text-4xl font-black text-white mb-2">المخطط التفاعلي</h2><p className="text-slate-400 font-bold">تصفية وبحث مباشر عن الوحدات داخل المخطط</p></div>
                  <div className="flex flex-col sm:flex-row gap-4 items-center flex-wrap">
                    <div className="relative w-full sm:w-64">
                      <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
                      <input 
                        type="text" 
                        placeholder="بحث عن كود..." 
                        value={floorPlanSearch}
                        onChange={(e) => setFloorPlanSearch(e.target.value)}
                        className="w-full pr-10 pl-4 py-3 bg-slate-800 border border-white/5 rounded-2xl text-xs font-black text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    {currentUser.role === 'ADMIN' && (
                      <label className="flex items-center gap-2 px-6 py-3 bg-slate-800 border border-white/5 rounded-2xl cursor-pointer hover:bg-slate-700 transition-all font-bold text-xs text-indigo-400 shadow-lg">
                        <ImageIcon className="w-4 h-4" /> رفع مخطط الدور
                        <input type="file" className="hidden" onChange={handleFloorPlanUpload} accept="image/*" />
                      </label>
                    )}
                    <div className="flex bg-slate-800 p-2 rounded-2xl border border-white/5 shadow-xl">
                       {['الأرضي', 'الأول', 'الثاني'].map(f => (
                         <button key={f} onClick={() => setSelectedFloor(f as any)} className={`px-8 py-3 rounded-xl font-black text-sm transition-all ${selectedFloor === f ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}>{f}</button>
                       ))}
                    </div>
                    <div className="flex bg-slate-800 p-2 rounded-2xl border border-white/5 shadow-xl">
                       {['ALL', 'تجاري', 'إداري', 'طبي'].map(t => (
                         <button key={t} onClick={() => setFloorPlanTypeFilter(t)} className={`px-6 py-3 rounded-xl font-black text-sm transition-all ${floorPlanTypeFilter === t ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
                           {t === 'ALL' ? 'الكل' : t}
                         </button>
                       ))}
                    </div>
                  </div>
               </header>

               <div className="flex-1 relative bg-slate-800/10 rounded-[3.5rem] border border-white/5 overflow-hidden shadow-2xl flex items-center justify-center min-h-[600px] border-indigo-500/10">
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_#4f46e555_0%,_transparent_70%)]"></div>
                  
                  <div className="relative w-full h-full flex items-center justify-center p-12">
                    {floorPlanImages[selectedFloor] ? (
                      <img src={floorPlanImages[selectedFloor]} className="max-w-full max-h-full object-contain rounded-3xl shadow-2xl transition-all duration-500" alt="Floor Plan" />
                    ) : (
                      <svg viewBox="0 0 100 100" className="w-full h-full max-w-4xl max-h-[80%] stroke-slate-700 fill-slate-900/40 opacity-50">
                        <rect x="10" y="10" width="80" height="80" rx="4" />
                        <rect x="35" y="35" width="30" height="30" rx="2" fill="transparent" strokeDasharray="2 2" />
                        <text x="50" y="52" textAnchor="middle" className="fill-slate-600 font-black text-[3px]" dir="rtl">يرجى رفع صورة مخطط لهذا الدور</text>
                      </svg>
                    )}

                    {units
                      .filter(u => 
                        u.floor === selectedFloor && 
                        (floorPlanTypeFilter === 'ALL' || u.type === floorPlanTypeFilter) &&
                        (floorPlanSearch === '' || u.code.toLowerCase().includes(floorPlanSearch.toLowerCase()))
                      )
                      .map(unit => (
                      <motion.div 
                        key={unit.id}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        style={{ left: `${unit.x}%`, top: `${unit.y}%` }}
                        className={`absolute -translate-x-1/2 -translate-y-1/2 group z-20`}
                      >
                         <div className={`
                            relative px-4 py-3 rounded-2xl border-2 font-black text-[11px] min-w-[140px] text-center shadow-[0_0_30px_rgba(0,0,0,0.4)] transition-all cursor-pointer hover:scale-110
                            ${unit.status === UnitStatus.AVAILABLE ? 'bg-green-500/30 border-green-500 text-green-300 shadow-green-500/10' : 
                              unit.status === UnitStatus.SOLD ? 'bg-red-500/30 border-red-500 text-red-300 shadow-red-500/10' : 
                              unit.status === UnitStatus.RESERVED ? 'bg-yellow-500/30 border-yellow-500 text-yellow-400 shadow-yellow-500/10' : 
                              'bg-slate-700/50 border-slate-500 text-slate-400'}
                         `}>
                            <div className="mb-1 text-xs opacity-60 font-bold">{unit.code}</div>
                            {unit.status === UnitStatus.AVAILABLE && <div className="text-white">متاح للبيع</div>}
                            {unit.status === UnitStatus.SOLD && (
                              <div className="leading-tight">
                                <span className="block text-[9px] opacity-70">ملك للمشتري</span>
                                <span className="text-white truncate block">{unit.soldTo || 'غير محدد'}</span>
                              </div>
                            )}
                            {unit.status === UnitStatus.RESERVED && (
                              <div className="leading-tight">
                                <span className="block text-[9px] opacity-70">محجوزة بواسطة</span>
                                <span className="text-white truncate block">{unit.reservedBy || 'سيد'}</span>
                              </div>
                            )}
                            {unit.status === UnitStatus.UNAVAILABLE && <div className="flex justify-center"><XCircle className="w-5 h-5 text-slate-500" /></div>}

                            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-3 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-50 w-64">
                              <div className="bg-slate-900/95 backdrop-blur-xl p-5 rounded-[1.5rem] shadow-2xl border border-white/10 text-right overflow-hidden">
                                 {unit.imageUrl && (
                                   <div className="h-32 -mx-5 -mt-5 mb-4 bg-slate-800 overflow-hidden border-b border-white/5">
                                     <img src={unit.imageUrl} className="w-full h-full object-cover" alt="Unit" />
                                   </div>
                                 )}
                                 <p className="text-indigo-400 text-[10px] font-black uppercase mb-1">{unit.type}</p>
                                 <p className="text-white text-sm font-black mb-3">{unit.code}</p>
                                 <div className="flex justify-between border-t border-white/5 pt-3">
                                    <span className="text-slate-500 text-[10px]">المساحة</span>
                                    <span className="text-slate-200 text-xs font-black">{unit.area} م²</span>
                                 </div>
                                 <div className="flex justify-between mt-1">
                                    <span className="text-slate-500 text-[10px]">السعر</span>
                                    <span className="text-green-400 text-xs font-black">{unit.price.toLocaleString()} ج.م</span>
                                 </div>
                                 <div className="mt-4 flex gap-2 pointer-events-auto">
                                    <button onClick={(e) => { e.stopPropagation(); setCalculatingUnit(unit); }} className="flex-1 py-2 bg-indigo-600 rounded-xl text-white text-[9px] font-black hover:bg-indigo-500 transition-all">حاسبة</button>
                                    {currentUser?.role === 'ADMIN' && <button onClick={(e) => { e.stopPropagation(); setEditingUnit(unit); setIsAddingUnit(true); }} className="flex-1 py-2 bg-slate-800 rounded-xl text-slate-400 text-[9px] font-black hover:bg-slate-700 transition-all">تعديل</button>}
                                 </div>
                              </div>
                            </div>
                         </div>
                      </motion.div>
                    ))}
                  </div>
               </div>

               <div className="grid grid-cols-2 md:grid-cols-4 gap-6 bg-slate-800/20 p-8 rounded-[2.5rem] border border-white/5 backdrop-blur-md">
                  <LegendItem color="bg-green-500" label="متاح (أخضر)" desc="وحدات جاهزة للتعاقد" />
                  <LegendItem color="bg-red-500" label="مباع (X)" desc="ملك للمشتري المسجل" />
                  <LegendItem color="bg-yellow-500" label="محجوز" desc="محجوزة بواسطة السيلز" />
                  <LegendItem color="bg-slate-500" label="غير متاح" desc="وحدات خارج العرض" />
               </div>
            </motion.div>
          )}

          {/* DASHBOARD VIEW */}
          {currentView === 'DASHBOARD' && (
            <motion.div key="dashboard" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div><h2 className="text-4xl font-black text-white mb-2">لوحة التحكم</h2><p className="text-slate-400 font-bold flex items-center gap-2"><Zap className="w-4 h-4 text-indigo-400" /> ملخص مبيعات المشروع</p></div>
                <div className="flex gap-4">
                   <button onClick={() => setCurrentView('REPORTS')} className="px-6 py-4 bg-slate-800 border border-white/5 rounded-2xl font-bold flex items-center gap-3 hover:bg-slate-700 transition-all"><FileText className="w-5 h-5 text-slate-400" /> التقارير</button>
                   {currentUser.role === 'ADMIN' && <button onClick={() => setIsAddingUnit(true)} className="px-6 py-4 bg-indigo-600 rounded-2xl font-black flex items-center gap-3 shadow-xl hover:bg-indigo-500 transition-all"><Plus className="w-5 h-5" /> إضافة وحدة</button>}
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                 <StatCard label="المبيعات الكلية" value={`${analyticsData.soldValue.toLocaleString()} ج.م`} subValue={`إجمالي التعاقدات`} icon={<DollarSign />} color="indigo" />
                 <StatCard label="نسبة الإنجاز" value={analyticsData.soldCount} subValue={`${((analyticsData.soldCount/units.length)*100).toFixed(1)}% من المشروع`} icon={<TrendingUp />} color="red" />
                 <StatCard label="حجوزات نشطة" value={analyticsData.reservedCount} subValue="قيد المراجعة" icon={<Clock />} color="yellow" />
                 <StatCard label="المخزون المتاح" value={analyticsData.availableCount} subValue="وحدة جاهزة للبيع" icon={<Zap />} color="green" />
              </div>
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                 <div className="xl:col-span-2 bg-slate-800/40 backdrop-blur-md rounded-[3rem] p-8 border border-white/5 shadow-2xl">
                    <h3 className="text-xl font-black text-white mb-8">تحليل المبيعات لكل دور</h3>
                    <div className="h-[350px] w-full">
                       <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={analyticsData.floorChart}>
                             <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                             <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                             <YAxis stroke="#64748b" fontSize={12} />
                             <ReTooltip contentStyle={{ background: '#1e293b', border: 'none', borderRadius: '15px' }} />
                             <Bar dataKey="sold" name="المباع" fill="#6366f1" radius={[10, 10, 0, 0]} barSize={40} />
                             <Bar dataKey="total" name="الإجمالي" fill="#ffffff10" radius={[10, 10, 0, 0]} barSize={40} />
                          </BarChart>
                       </ResponsiveContainer>
                    </div>
                 </div>
                 <div className="bg-slate-800/40 backdrop-blur-md rounded-[3rem] p-8 border border-white/5 shadow-2xl">
                    <h3 className="text-xl font-black text-white mb-8">حالة المخزون</h3>
                    <div className="h-[250px] w-full relative">
                        <ResponsiveContainer width="100%" height="100%">
                           <RePieChart>
                              <Pie data={analyticsData.pieData} innerRadius={80} outerRadius={110} paddingAngle={8} dataKey="value">
                                 {analyticsData.pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                              </Pie>
                              <ReTooltip />
                           </RePieChart>
                        </ResponsiveContainer>
                        <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none"><span className="text-3xl font-black text-white">{analyticsData.totalCount}</span><span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">إجمالي الوحدات</span></div>
                    </div>
                    <div className="mt-8 space-y-3">
                       {analyticsData.pieData.map(d => (
                         <div key={d.name} className="flex justify-between items-center text-xs font-bold">
                            <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full" style={{ background: d.color }}></div><span className="text-slate-400">{d.name}</span></div>
                            <span className="text-white">{d.value}</span>
                         </div>
                       ))}
                    </div>
                 </div>
              </div>
            </motion.div>
          )}

          {/* INVENTORY VIEW */}
          {currentView === 'INVENTORY' && (
            <motion.div key="inventory" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }} className="space-y-8">
               <header className="flex flex-col xl:flex-row xl:items-center justify-between gap-6">
                  <div><h2 className="text-4xl font-black text-white mb-2">مستودع الوحدات</h2><p className="text-slate-400 font-bold">إدارة تفصيلية وصور لجميع مساحات المشروع</p></div>
                  <div className="flex flex-wrap items-center gap-3">
                    {currentUser.role === 'ADMIN' && (<button onClick={() => setIsAddingUnit(true)} className="flex items-center gap-3 px-8 py-4 bg-indigo-600 text-white rounded-[1.5rem] hover:bg-indigo-700 shadow-xl font-black transition-all"><Plus className="w-6 h-6" /> إضافة وحدة</button>)}
                    <label className="flex items-center gap-3 px-6 py-4 bg-slate-800 border border-white/5 rounded-[1.5rem] cursor-pointer hover:bg-slate-700 transition-all font-bold text-slate-300 shadow-lg"><Upload className="w-5 h-5 text-indigo-400" /> استيراد Excel<input type="file" className="hidden" onChange={handleExcelUpload} /></label>
                  </div>
               </header>
               
               <div className="bg-slate-800/40 p-5 rounded-[2.5rem] border border-white/5 flex flex-col lg:flex-row items-center gap-6 shadow-2xl">
                  {currentUser.role === 'ADMIN' && (
                    <button 
                      onClick={toggleSelectAll} 
                      className={`flex items-center gap-3 px-6 py-4 rounded-2xl font-black text-sm transition-all shadow-lg ${selectedUnitIds.length > 0 && selectedUnitIds.length === filteredInventoryUnits.length ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 border border-white/5'}`}
                    >
                      {selectedUnitIds.length === filteredInventoryUnits.length ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5" />}
                      تحديد الكل
                    </button>
                  )}
                  <div className="relative flex-1 w-full"><Search className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 w-6 h-6" /><input type="text" placeholder="ابحث بكود الوحدة أو المشتري..." className="w-full pr-14 pl-6 py-4 bg-slate-900/50 border-none rounded-2xl font-bold text-slate-200 outline-none focus:ring-2 focus:ring-indigo-500 transition-all shadow-inner" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
                  <div className="flex items-center gap-2 bg-slate-900/50 p-1.5 rounded-2xl border border-white/5 shadow-inner">
                    {['ALL', UnitStatus.AVAILABLE, UnitStatus.RESERVED, UnitStatus.SOLD].map((st) => (
                      <button key={st} onClick={() => setFilter(st)} className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all ${filter === st ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}>{st === 'ALL' ? 'الكل' : STATUS_LABELS[st as UnitStatus].label}</button>
                    ))}
                  </div>
               </div>

               {/* Bulk Actions Floating Bar */}
               <AnimatePresence>
                 {currentUser.role === 'ADMIN' && selectedUnitIds.length > 0 && (
                   <motion.div initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 50, opacity: 0 }} className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[100] bg-slate-900/90 backdrop-blur-2xl border border-indigo-500/30 px-10 py-5 rounded-[2.5rem] shadow-2xl flex items-center gap-8 min-w-[400px]">
                      <div className="flex items-center gap-4 border-l border-white/10 pl-8">
                         <span className="text-white font-black text-xl">{selectedUnitIds.length}</span>
                         <span className="text-slate-500 font-bold text-sm">وحدة محددة</span>
                      </div>
                      <div className="flex items-center gap-4">
                         <button onClick={deleteSelectedUnits} className="flex items-center gap-3 px-6 py-3 bg-red-600/10 text-red-500 hover:bg-red-600 hover:text-white rounded-xl font-black transition-all shadow-xl border border-red-500/20"><Trash2 className="w-5 h-5" /> حذف المحدد</button>
                         <button onClick={() => setSelectedUnitIds([])} className="flex items-center gap-3 px-6 py-3 bg-slate-800 text-slate-400 hover:text-white rounded-xl font-black transition-all border border-white/5">إلغاء</button>
                      </div>
                   </motion.div>
                 )}
               </AnimatePresence>

               <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 pb-32 text-right">
                  {filteredInventoryUnits.map(unit => (
                    <div key={unit.id} className="relative">
                      {currentUser.role === 'ADMIN' && (
                        <button 
                          onClick={() => toggleSelectUnit(unit.id)}
                          className={`absolute top-4 left-4 z-30 w-10 h-10 rounded-xl flex items-center justify-center transition-all shadow-2xl ${selectedUnitIds.includes(unit.id) ? 'bg-indigo-600 text-white scale-110' : 'bg-slate-900/50 backdrop-blur-md text-white/20 border border-white/5 hover:text-white hover:scale-105'}`}
                        >
                           {selectedUnitIds.includes(unit.id) ? <CheckSquare className="w-6 h-6" /> : <Square className="w-6 h-6" />}
                        </button>
                      )}
                      <UnitCard 
                        unit={unit} 
                        onCalc={() => setCalculatingUnit(unit)} 
                        onEdit={() => {setEditingUnit(unit); setIsAddingUnit(true);}} 
                        onShare={() => handleShareUnit(unit)}
                        onDelete={() => deleteUnit(unit.id)}
                        onImageClick={() => unit.imageUrl && setFullScreenImage(unit.imageUrl)}
                        currentUser={currentUser} 
                        selected={selectedUnitIds.includes(unit.id)}
                      />
                    </div>
                  ))}
               </div>
            </motion.div>
          )}

          {/* ANALYTICS VIEW */}
          {currentView === 'ANALYTICS' && (
            <motion.div key="analytics" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
               <header><h2 className="text-4xl font-black text-white mb-2">تحليل البيانات المعمق</h2><p className="text-slate-400 font-bold">رؤى ذكية حول أداء المبيعات والاستراتيجية</p></header>
               <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                  <div className="bg-slate-800/40 p-8 rounded-[3rem] border border-white/5 shadow-2xl">
                     <h3 className="text-xl font-black text-white mb-8">المبيعات حسب نوع الوحدة</h3>
                     <div className="h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                           <BarChart data={[
                             { name: 'تجاري', sold: units.filter(u => u.type === 'تجاري' && u.status === UnitStatus.SOLD).length, total: units.filter(u => u.type === 'تجاري').length },
                             { name: 'إداري', sold: units.filter(u => u.type === 'إداري' && u.status === UnitStatus.SOLD).length, total: units.filter(u => u.type === 'إداري').length },
                             { name: 'طبي', sold: units.filter(u => u.type === 'طبي' && u.status === UnitStatus.SOLD).length, total: units.filter(u => u.type === 'طبي').length },
                           ]}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                              <XAxis dataKey="name" stroke="#64748b" />
                              <YAxis stroke="#64748b" />
                              <ReTooltip contentStyle={{ background: '#1e293b', border: 'none', borderRadius: '15px' }} />
                              <Legend />
                              <Bar dataKey="sold" name="المباع" fill="#6366f1" radius={[10, 10, 0, 0]} />
                              <Bar dataKey="total" name="الإجمالي" fill="#ffffff10" radius={[10, 10, 0, 0]} />
                           </BarChart>
                        </ResponsiveContainer>
                     </div>
                  </div>
                  <div className="bg-slate-800/40 p-8 rounded-[3rem] border border-white/5 shadow-2xl overflow-y-auto">
                     <h3 className="text-xl font-black text-white mb-8">ترتيب السيلز (حسب الحجوزات)</h3>
                     <div className="space-y-6">
                        {Array.from(new Set(units.map(u => u.reservedBy).filter(Boolean))).map(sales => (
                          <div key={sales} className="flex items-center gap-4">
                             <div className="w-32 text-sm font-bold text-slate-400 truncate">{sales}</div>
                             <div className="flex-1 h-3 bg-slate-700 rounded-full overflow-hidden">
                                <motion.div 
                                  initial={{ width: 0 }} 
                                  animate={{ width: `${(units.filter(u => u.reservedBy === sales).length / units.length) * 100}%` }} 
                                  className="h-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]" 
                                />
                             </div>
                             <div className="w-10 text-xs font-black text-white">{units.filter(u => u.reservedBy === sales).length}</div>
                          </div>
                        ))}
                     </div>
                  </div>
               </div>
            </motion.div>
          )}

          {/* MARKETING VIEW */}
          {currentView === 'MARKETING' && (
            <motion.div key="marketing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
               <header><h2 className="text-4xl font-black text-white mb-2">التسويق الذكي</h2><p className="text-slate-400 font-bold">إنشاء محتوى ترويجي فوري لكل وحدة باستخدام الذكاء الاصطناعي</p></header>
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-10">
                  {units.filter(u => u.status === UnitStatus.AVAILABLE).map(unit => (
                    <div key={unit.id} className="bg-slate-800/40 p-6 rounded-[2.5rem] border border-white/5 shadow-2xl group flex flex-col hover:-translate-y-2 transition-all">
                       <div 
                        className="aspect-video bg-slate-900 rounded-2xl mb-6 overflow-hidden relative cursor-zoom-in"
                        onClick={() => unit.imageUrl && setFullScreenImage(unit.imageUrl)}
                       >
                          {unit.imageUrl ? (
                            <img src={unit.imageUrl} className="w-full h-full object-cover" alt="" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-700 font-black text-2xl bg-indigo-600/5">{unit.code}</div>
                          )}
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                             <ZoomIn className="w-10 h-10 text-white" />
                          </div>
                       </div>
                       <div className="flex-1">
                          <h3 className="text-xl font-black text-white mb-2">{unit.code}</h3>
                          <p className="text-xs text-slate-400 mb-6 font-bold uppercase tracking-widest">{unit.type} • {unit.area} م² • {unit.price.toLocaleString()} ج.م</p>
                       </div>
                       <button onClick={() => generateAIPost(unit)} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 shadow-lg shadow-indigo-600/20"><Sparkles className="w-4 h-4" /> توليد إعلان ممول</button>
                    </div>
                  ))}
               </div>
            </motion.div>
          )}

          {/* REPORTS VIEW */}
          {currentView === 'REPORTS' && (
            <motion.div key="reports" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
               <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div><h2 className="text-4xl font-black text-white mb-2">تقارير النظام</h2><p className="text-slate-400 font-bold">جرد شامل وحالة المشروع الحالية للاستخدام المكتبي</p></div>
                  <button onClick={() => {
                    const ws = XLSX.utils.json_to_sheet(units.map(u => ({
                      "الكود": u.code,
                      "النوع": u.type,
                      "الدور": u.floor,
                      "المساحة": u.area,
                      "السعر": u.price,
                      "الحالة": STATUS_LABELS[u.status].label,
                      "المشتري": u.soldTo || '-',
                      "السيلز": u.reservedBy || '-'
                    })));
                    const wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(wb, ws, "Units Inventory");
                    XLSX.writeFile(wb, "CityBuyer_Inventory_Report.xlsx");
                  }} className="px-8 py-4 bg-green-600 text-white rounded-2xl font-black shadow-xl shadow-green-600/20 flex items-center gap-3 hover:bg-green-700 transition-all"><FileSpreadsheet className="w-6 h-6" /> تصدير إكسيل كامل</button>
               </header>
               <div className="bg-slate-800/40 rounded-[2.5rem] border border-white/5 overflow-x-auto shadow-2xl">
                  <table className="w-full text-right border-collapse min-w-[800px]">
                     <thead>
                        <tr className="bg-slate-900/50 text-slate-500 text-[10px] uppercase font-black tracking-widest">
                           <th className="p-6">كود الوحدة</th>
                           <th className="p-6">النوع</th>
                           <th className="p-6">المساحة</th>
                           <th className="p-6">السعر</th>
                           <th className="p-6">الحالة</th>
                           <th className="p-6">التفاصيل</th>
                        </tr>
                     </thead>
                     <tbody className="text-sm font-bold divide-y divide-white/5">
                        {units.map(u => (
                          <tr key={u.id} className="hover:bg-white/5 transition-all group">
                             <td className="p-6 text-white font-black group-hover:text-indigo-400 transition-colors">{u.code}</td>
                             <td className="p-6">{u.type}</td>
                             <td className="p-6">{u.area} م²</td>
                             <td className="p-6 text-indigo-400">{u.price.toLocaleString()} ج.م</td>
                             <td className="p-6"><StatusBadge status={u.status} /></td>
                             <td className="p-6 text-slate-400">{u.soldTo ? `مشترٍ: ${u.soldTo}` : u.reservedBy ? `محجوز لـ: ${u.reservedBy}` : 'متاح'}</td>
                          </tr>
                        ))}
                     </tbody>
                  </table>
               </div>
            </motion.div>
          )}

        </AnimatePresence>

        <button onClick={() => setIsChatOpen(true)} className="fixed bottom-10 right-10 w-20 h-20 bg-indigo-600 text-white rounded-[2rem] shadow-2xl flex items-center justify-center hover:scale-110 transition-all z-50 accent-glow"><Sparkles className="w-10 h-10" /></button>
      </main>

      {/* FULL SCREEN IMAGE MODAL */}
      <AnimatePresence>
        {fullScreenImage && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            className="fixed inset-0 z-[500] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-2xl cursor-zoom-out"
            onClick={() => setFullScreenImage(null)}
          >
             <motion.button 
                initial={{ scale: 0 }} 
                animate={{ scale: 1 }} 
                className="absolute top-10 right-10 w-16 h-16 bg-white/10 text-white rounded-2xl flex items-center justify-center hover:bg-white/20 transition-all shadow-2xl z-[510]"
             >
                <X className="w-10 h-10" />
             </motion.button>
             <motion.img 
                initial={{ scale: 0.8, opacity: 0 }} 
                animate={{ scale: 1, opacity: 1 }} 
                exit={{ scale: 0.8, opacity: 0 }}
                src={fullScreenImage} 
                className="max-w-[90vw] max-h-[90vh] object-contain rounded-3xl shadow-[0_0_100px_rgba(0,0,0,0.8)] border border-white/10" 
                alt="Full View" 
             />
          </motion.div>
        )}
      </AnimatePresence>

      {/* CALCULATOR MODAL */}
      <AnimatePresence>
        {calculatingUnit && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-2xl">
             <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="bg-[#0a0f1d] w-full max-w-5xl rounded-[3.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row border border-white/5">
                <div className="md:w-[40%] bg-indigo-600 p-12 text-white flex flex-col justify-between relative overflow-hidden text-right">
                    <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
                    <div className="relative z-10"><div className="inline-flex p-4 bg-white/10 rounded-[1.5rem] mb-8"><Wallet className="w-10 h-10 text-white" /></div><h3 className="text-3xl font-black mb-2 tracking-tighter">حاسبة سيتي باير</h3><p className="text-indigo-100 font-bold opacity-70">الوحدة: {calculatingUnit.code}</p></div>
                    <div className="space-y-8 relative z-10">
                        <div className="bg-white/10 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl"><p className="text-[10px] font-black text-indigo-200 mb-4 uppercase tracking-widest">القسط الشهري المتوقع</p><div className="flex items-baseline gap-2 justify-end"><span className="text-5xl font-black">{Math.round(calculatedMonthly).toLocaleString()}</span><span className="text-lg opacity-60">ج.م</span></div></div>
                        <div className="space-y-4 px-2">
                          <ResultRow label="إجمالي السعر" value={calculatedTotal} /><ResultRow label="المقدم المطلق" value={calculatedDownPayment} highlight /><ResultRow label="المبلغ المتبقي" value={calculatedRemaining} />
                        </div>
                    </div>
                </div>
                <div className="flex-1 p-12 bg-[#0a0f1d] overflow-y-auto">
                  <div className="flex items-center justify-between mb-12"><div><h4 className="text-2xl font-black text-white">خطط السداد</h4><p className="text-slate-500 font-bold">تحكم في خيارات التمويل المتاحة</p></div><button onClick={() => setCalculatingUnit(null)} className="w-14 h-14 flex items-center justify-center bg-slate-800 rounded-2xl hover:bg-slate-700 transition-all"><X className="w-8 h-8 text-slate-400" /></button></div>
                  <div className="space-y-10">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <InputFieldCalc label="سعر المتر" value={calcPricePerMeter} onChange={setCalcPricePerMeter} icon={<DollarSign className="w-4 h-4 text-indigo-500" />} />
                          <InputFieldCalc label="مساحة الوحدة" value={calcArea} onChange={setCalcArea} icon={<TrendingUp className="w-4 h-4 text-indigo-500" />} />
                      </div>
                      <div className="space-y-10 pt-4">
                          <SliderField label="نسبة المقدم المدفوع" value={calcDownPaymentPercent} onChange={setCalcDownPaymentPercent} min={0} max={90} step={5} unit="%" />
                          <SliderField label="مدة التقسيط الكلية" value={calcYears} onChange={setCalcYears} min={1} max={15} step={1} unit="سنة" />
                      </div>
                      <div className="pt-12 flex flex-col md:flex-row gap-6">
                          {currentUser.role === 'ADMIN' && (<button onClick={() => {saveUnit({ ...calculatingUnit, price: calculatedTotal, area: calcArea }); setCalculatingUnit(null);}} className="flex-1 py-6 bg-white text-slate-900 rounded-[1.5rem] font-black hover:bg-slate-100 transition-all flex items-center justify-center gap-4 text-lg shadow-xl"><Save className="w-7 h-7" /> اعتماد السعر</button>)}
                          <button onClick={() => setCalculatingUnit(null)} className="py-6 flex-1 border-2 border-white/10 text-slate-400 rounded-[1.5rem] font-black hover:bg-white/5 transition-all">إغلاق الحاسبة</button>
                      </div>
                  </div>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* AI ASSISTANT MODAL */}
      <AnimatePresence>
        {isChatOpen && (
          <motion.div initial={{ opacity: 0, x: 400 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 400 }} className="fixed inset-y-0 right-0 w-full md:w-[600px] bg-[#0a0f1d] z-[200] border-r border-white/5 shadow-2xl flex flex-col">
             <div className="p-8 bg-indigo-600 text-white flex items-center justify-between shadow-xl">
                <div className="flex items-center gap-5"><div className="w-16 h-16 bg-white/10 rounded-[1.5rem] flex items-center justify-center shadow-inner"><Sparkles className="w-8 h-8 text-white" /></div><h3 className="text-2xl font-black tracking-tighter">City Buyer AI</h3></div>
                <button onClick={() => setIsChatOpen(false)} className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"><X className="w-7 h-7" /></button>
             </div>
             <div className="flex-1 overflow-y-auto p-8 space-y-8">
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-start' : 'justify-end'} gap-4`}>
                     <div className={`max-w-[85%] p-6 rounded-[2.25rem] text-sm font-bold shadow-lg leading-relaxed ${m.role === 'user' ? 'bg-slate-800 text-slate-200 rounded-tr-none' : 'bg-indigo-600 text-white rounded-tl-none'}`}>
                        {m.content}
                     </div>
                  </div>
                ))}
                {isTyping && <div className="text-indigo-400 font-bold text-xs flex items-center gap-2 px-8"><Loader2 className="w-3 h-3 animate-spin" /> جاري التفكير بذكاء...</div>}
                <div ref={chatEndRef} />
             </div>
             <div className="p-8 border-t border-white/5 bg-slate-900/50">
                <div className="relative flex items-center gap-3">
                   <input type="text" value={chatInput} onChange={(e) => setChatInput(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()} placeholder="اسأل عن أي وحدة أو اطلب بوست تسويقي..." className="flex-1 py-5 px-6 bg-slate-800 rounded-2xl border-none font-bold text-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-right" dir="rtl" />
                   <div className="flex gap-2">
                     <button onClick={() => setIsThinkingMode(!isThinkingMode)} className={`p-5 rounded-2xl transition-all shadow-lg ${isThinkingMode ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500'}`} title="نمط التفكير العميق"><BrainCircuit className="w-6 h-6" /></button>
                     <button onClick={() => handleSendMessage()} className="p-5 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-600/20"><Send className="w-6 h-6" /></button>
                   </div>
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ADD/EDIT UNIT MODAL */}
      <AnimatePresence>
         {isAddingUnit && (
           <div className="fixed inset-0 z-[250] flex items-center justify-center p-6 bg-slate-950/60 backdrop-blur-xl">
             <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-slate-900 w-full max-w-6xl rounded-[3.5rem] shadow-2xl flex flex-col md:flex-row overflow-hidden max-h-[90vh]">
                <div className="flex-1 p-10 overflow-y-auto">
                   <div className="flex justify-between items-center mb-10"><h3 className="text-3xl font-black text-white tracking-tighter">{editingUnit ? 'تحديث بيانات الوحدة' : 'إضافة وحدة للمستودع'}</h3><button onClick={() => setIsAddingUnit(false)}><X className="w-6 h-6 text-slate-400 hover:text-white transition-all" /></button></div>
                   
                   <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                      <div className="lg:col-span-2 space-y-6">
                        <form id="unitForm" onSubmit={(e) => { e.preventDefault(); const fd = new FormData(e.currentTarget); saveUnit({ code: fd.get('code') as string, price: Number(fd.get('price')), area: Number(fd.get('area')), type: fd.get('type') as string, floor: fd.get('floor') as string, status: fd.get('status') as UnitStatus, soldTo: fd.get('soldTo') as string, reservedBy: fd.get('reservedBy') as string }); }} className="space-y-6">
                            <div className="grid grid-cols-2 gap-6">
                              <InputField label="كود الوحدة" name="code" defaultValue={editingUnit?.code} required />
                              <InputField label="المساحة الإجمالية (م²)" name="area" type="number" defaultValue={editingUnit?.area} required />
                              <InputField label="سعر الوحدة الكلي" name="price" type="number" defaultValue={editingUnit?.price} required />
                              <div className="space-y-2"><label className="text-[10px] font-black text-slate-500 uppercase px-2 tracking-widest">الدور</label><select name="floor" defaultValue={editingUnit?.floor} className="w-full px-6 py-4 bg-slate-800 rounded-2xl font-black text-slate-200 focus:ring-2 focus:ring-indigo-500 appearance-none outline-none transition-all text-right"><option value="الأرضي">الأرضي</option><option value="الأول">الأول</option><option value="الثاني">الثاني</option></select></div>
                              <div className="space-y-2"><label className="text-[10px] font-black text-slate-500 uppercase px-2 tracking-widest">نوع الاستخدام</label><select name="type" defaultValue={editingUnit?.type} className="w-full px-6 py-4 bg-slate-800 rounded-2xl font-black text-slate-200 focus:ring-2 focus:ring-indigo-500 appearance-none outline-none transition-all text-right"><option value="تجاري">تجاري</option><option value="إداري">إداري</option><option value="طبي">طبي</option></select></div>
                              <div className="space-y-2"><label className="text-[10px] font-black text-slate-500 uppercase px-2 tracking-widest">حالة البيع</label><select name="status" defaultValue={editingUnit?.status} className="w-full px-6 py-4 bg-slate-800 rounded-2xl font-black text-slate-200 focus:ring-2 focus:ring-indigo-500 appearance-none outline-none transition-all text-right">{Object.keys(STATUS_LABELS).map(st => <option key={st} value={st}>{STATUS_LABELS[st as UnitStatus].label}</option>)}</select></div>
                              <InputField label="اسم المشتري المتعاقد" name="soldTo" defaultValue={editingUnit?.soldTo} />
                              <InputField label="اسم السيلز المسؤول" name="reservedBy" defaultValue={editingUnit?.reservedBy} />
                            </div>
                        </form>
                      </div>

                      <div className="space-y-6">
                        <label className="text-[10px] font-black text-slate-500 uppercase px-2 block tracking-widest">صورة الوحدة / المخطط</label>
                        <div className="aspect-square bg-slate-800 rounded-[2.5rem] border-4 border-dashed border-white/5 flex flex-col items-center justify-center p-6 relative overflow-hidden group hover:border-indigo-500/30 transition-all">
                           {unitImagePreview ? (
                             <>
                               <img src={unitImagePreview} className="w-full h-full object-cover" alt="Preview" />
                               <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                  <button onClick={() => setUnitImagePreview(null)} className="p-4 bg-red-500 text-white rounded-2xl shadow-xl hover:scale-110 transition-all"><Trash2 className="w-6 h-6" /></button>
                               </div>
                             </>
                           ) : (
                             <>
                               <ImageIcon className="w-16 h-16 text-slate-700 mb-4" />
                               <p className="text-slate-500 font-bold text-center text-sm">اسحب الصورة هنا أو اضغط للتحميل</p>
                             </>
                           )}
                           <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleUnitImageUpload} accept="image/*" />
                        </div>
                        <p className="text-[10px] text-slate-500 text-center font-bold">يفضل رفع صور حقيقية للوحدة لتعزيز التسويق الذكي</p>
                      </div>
                   </div>

                   <div className="mt-10 flex gap-4">
                      <button type="submit" form="unitForm" className="flex-1 py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black hover:bg-indigo-700 shadow-xl shadow-indigo-600/20 transition-all text-lg">حفظ كافة البيانات</button>
                      <button onClick={() => setIsAddingUnit(false)} className="px-10 py-5 border-2 border-white/5 text-slate-400 rounded-[1.5rem] font-black hover:bg-white/5 transition-all">إلغاء التغييرات</button>
                   </div>
                </div>
             </motion.div>
           </div>
         )}
      </AnimatePresence>

    </div>
  );
}

// --- Helper Components ---

const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button onClick={onClick} className={`flex items-center gap-4 px-6 py-4 rounded-[1.25rem] font-black transition-all w-full text-right ${active ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/30' : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
    {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: 'w-6 h-6' }) : icon}
    <span className="text-sm">{label}</span>
  </button>
);

const LegendItem: React.FC<{ color: string; label: string; desc: string }> = ({ color, label, desc }) => (
  <div className="flex items-center gap-4 group">
    <div className={`w-12 h-12 rounded-2xl ${color} bg-opacity-20 border-2 border-${color.split('-')[1]}-500/50 flex items-center justify-center shrink-0 group-hover:scale-110 transition-all`}>
       <div className={`w-4 h-4 rounded-full ${color}`}></div>
    </div>
    <div>
       <span className="text-xs font-black text-white block">{label}</span>
       <span className="text-[10px] text-slate-500 block">{desc}</span>
    </div>
  </div>
);

const StatCard: React.FC<{ label: string; value: string | number; subValue: string; icon: React.ReactNode; color: string }> = ({ label, value, subValue, icon, color }) => {
  const colors: Record<string, string> = { indigo: 'bg-indigo-600', red: 'bg-red-500', yellow: 'bg-yellow-500', green: 'bg-green-500' };
  return (
    <div className="bg-slate-800/40 p-8 rounded-[2.5rem] border border-white/5 shadow-2xl flex flex-col justify-between group hover:-translate-y-1 hover:bg-slate-800/60 transition-all">
       <div className="flex justify-between items-start mb-6"><div className={`p-4 rounded-2xl ${colors[color]} bg-opacity-10 text-white group-hover:scale-110 transition-all`}>{icon}</div><p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</p></div>
       <div><p className="text-3xl font-black text-white mb-2 tracking-tighter">{value}</p><p className="text-xs font-bold text-slate-500">{subValue}</p></div>
    </div>
  );
};

const UnitCard: React.FC<{ unit: Unit; onCalc: () => void; onEdit: () => void; onShare: () => void; onDelete: () => void; onImageClick: () => void; currentUser: User; selected?: boolean }> = ({ unit, onCalc, onEdit, onShare, onDelete, onImageClick, currentUser, selected }) => (
  <motion.div layout initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className={`bg-slate-800/40 rounded-[2.5rem] overflow-hidden border shadow-2xl group flex flex-col hover:-translate-y-2 transition-all ${selected ? 'border-indigo-500 bg-indigo-500/5' : 'border-white/5'}`}>
    <div className="relative h-60 bg-slate-900 flex items-center justify-center overflow-hidden">
       {unit.imageUrl ? (
         <img 
            src={unit.imageUrl} 
            className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-700 cursor-zoom-in" 
            alt="Unit" 
            onClick={onImageClick}
         />
       ) : (
         <div className="w-full h-full flex items-center justify-center text-slate-800 font-black text-5xl bg-indigo-600/5">{unit.code}</div>
       )}
       <div className="absolute top-4 right-4"><StatusBadge status={unit.status} /></div>
       
       <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-end p-6">
          <div className="flex flex-col gap-2 w-full">
            <div className="flex gap-2">
               <button onClick={(e) => { e.stopPropagation(); onCalc(); }} className="flex-1 py-3 bg