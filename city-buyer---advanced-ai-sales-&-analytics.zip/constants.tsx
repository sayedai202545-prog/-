
import React from 'react';
import { 
  CheckCircle, 
  Clock, 
  XCircle, 
  Slash
} from 'lucide-react';
import { UnitStatus, Unit } from './types';

export const STATUS_LABELS: Record<UnitStatus, { label: string; color: string; icon: React.ReactNode }> = {
  [UnitStatus.AVAILABLE]: { 
    label: 'متاح', 
    color: 'bg-green-500/20 text-green-400 border-green-500/50',
    icon: <CheckCircle className="w-4 h-4" />
  },
  [UnitStatus.UNAVAILABLE]: { 
    label: 'غير متاح', 
    color: 'bg-slate-500/20 text-slate-400 border-slate-500/50',
    icon: <Slash className="w-4 h-4" />
  },
  [UnitStatus.RESERVED]: { 
    label: 'محجوز', 
    color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
    icon: <Clock className="w-4 h-4" />
  },
  [UnitStatus.SOLD]: { 
    label: 'مباع', 
    color: 'bg-red-500/20 text-red-400 border-red-500/50',
    icon: <XCircle className="w-4 h-4" />
  },
};

export const INITIAL_UNITS: Unit[] = [
  // الدور الأرضي (Ground Floor - Page 1)
  { id: 'g1', code: 'G-A-11', type: 'تجاري', floor: 'الأرضي', area: 24, price: 1500000, status: UnitStatus.AVAILABLE, lastUpdate: Date.now(), x: 18, y: 21 },
  { id: 'g2', code: 'G-A-14', type: 'تجاري', floor: 'الأرضي', area: 63, price: 4200000, status: UnitStatus.SOLD, soldTo: 'أحمد محمود سليمان', lastUpdate: Date.now(), x: 23, y: 33 },
  { id: 'g3', code: 'G-A-15', type: 'تجاري', floor: 'الأرضي', area: 38, price: 2400000, status: UnitStatus.RESERVED, reservedBy: 'سيد إبراهيم', lastUpdate: Date.now(), x: 21, y: 44 },
  { id: 'g4', code: 'G-A-16', type: 'تجاري', floor: 'الأرضي', area: 38, price: 2400000, status: UnitStatus.UNAVAILABLE, lastUpdate: Date.now(), x: 21, y: 54 },
  { id: 'g5', code: 'G-A-01', type: 'تجاري', floor: 'الأرضي', area: 44, price: 2800000, status: UnitStatus.AVAILABLE, lastUpdate: Date.now(), x: 45, y: 78 },
  { id: 'g6', code: 'G-A-02', type: 'تجاري', floor: 'الأرضي', area: 36, price: 2100000, status: UnitStatus.AVAILABLE, lastUpdate: Date.now(), x: 45, y: 68 },
  { id: 'g7', code: 'G-A-05', type: 'تجاري', floor: 'الأرضي', area: 38, price: 2400000, status: UnitStatus.RESERVED, reservedBy: 'مروة علي', lastUpdate: Date.now(), x: 76, y: 21 },

  // الدور الأول (First Floor - Page 2)
  { id: 'f1', code: 'F-A-11', type: 'إداري', floor: 'الأول', area: 39, price: 1900000, status: UnitStatus.AVAILABLE, lastUpdate: Date.now(), x: 16, y: 35 },
  { id: 'f2', code: 'F-A-03', type: 'إداري', floor: 'الأول', area: 123, price: 5800000, status: UnitStatus.SOLD, soldTo: 'شركة الخليج للاستثمار', lastUpdate: Date.now(), x: 82, y: 25 },
  { id: 'f3', code: 'F-A-01', type: 'إداري', floor: 'الأول', area: 88, price: 4100000, status: UnitStatus.AVAILABLE, lastUpdate: Date.now(), x: 47, y: 78 },

  // الدور الثاني (Second Floor - Page 3)
  { id: 's1', code: 'S-A-06', type: 'طبي', floor: 'الثاني', area: 43, price: 2100000, status: UnitStatus.AVAILABLE, lastUpdate: Date.now(), x: 18, y: 35 },
  { id: 's2', code: 'S-A-01', type: 'طبي', floor: 'الثاني', area: 123, price: 6200000, status: UnitStatus.RESERVED, reservedBy: 'د. يوسف شريف', lastUpdate: Date.now(), x: 80, y: 25 },
  { id: 's3', code: 'S-A-10', type: 'طبي', floor: 'الثاني', area: 35, price: 1700000, status: UnitStatus.AVAILABLE, lastUpdate: Date.now(), x: 31, y: 84 },
];
