
export enum UnitStatus {
  AVAILABLE = 'AVAILABLE',
  UNAVAILABLE = 'UNAVAILABLE',
  RESERVED = 'RESERVED',
  SOLD = 'SOLD'
}

export interface Unit {
  id: string;
  code: string;
  type: string;
  floor: string;
  area: number;
  price: number;
  status: UnitStatus;
  reservedBy?: string;
  soldTo?: string; // المشتري
  soldBy?: string; // السيلز الذي باع
  imageUrl?: string;
  lastUpdate: number;
  // إحداثيات افتراضية للمخطط التفاعلي
  x?: number;
  y?: number;
}

export interface User {
  id: string;
  name: string;
  role: 'ADMIN' | 'SALES';
}

export type AppState = {
  units: Unit[];
  currentUser: User | null;
};
